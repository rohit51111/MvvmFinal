package `in`.bitcode.mvvmdemo.repo

open class BaseRepo